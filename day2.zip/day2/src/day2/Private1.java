package day2;

public class Private1 {

	public static void main(String[] args) {
		Private p=new Private();
		p.display();

	}

}
