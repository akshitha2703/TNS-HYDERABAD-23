package day2;

public class Approach {

	int b=20;
	static int c=10;
	public static void main(String[] args) {
		int c=10;
		Approach a=new Approach();
		System.out.println(c);
		System.out.println(a.b);
		System.out.println(a.c);

	}
}
