package day2;

public class Protected {
	protected void display() {
		 System.out.println("protected");
	}
	public static void main(String[] args) {
		Protected p=new Protected();
		p.display();
	}


}
