package day2;

public class Public1 {

	public static void main(String[] args) {
		Public p=new Public();
		p.display();

	}

}
