package day2;

public class Private {
	private void display() {
		 System.out.println("private");

	}
	public static void main(String[] args) {
		Private p=new Private();
		p.display();

	}

}
