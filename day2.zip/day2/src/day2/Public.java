package day2;

public class Public {
 public void display() {
	 System.out.println("public");
 }
	public static void main(String[] args) {
     Public p=new Public();
     p.display();

	}

}
