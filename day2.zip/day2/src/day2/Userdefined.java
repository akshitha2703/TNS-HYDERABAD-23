package day2;

public class Userdefined {
	public void msg() {


		System.out.println("hello A");

	}

}

