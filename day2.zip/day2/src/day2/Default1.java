package day2;

public class Default1 {

	public static void main(String[] args) {
		Default d=new Default();
		d.display();
		
	}

}
