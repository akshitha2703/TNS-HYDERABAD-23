package day2;

public class Apprach1 {
int b=10;
public char[] apprach1;
static int c=10;
void display() {
	System.out.println("akshitha");
}
static int display1() {
	return 10;
}
class C{
	public static void main(String[] args) {
		Apprach1 a=new Apprach1();
		a.display();
		System.out.println(Apprach1.display1());
		}
	}
}




