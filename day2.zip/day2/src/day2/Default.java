package day2;

public class Default {
	void display() {
		System.out.println("defalt");
		
	

	

	}

}
