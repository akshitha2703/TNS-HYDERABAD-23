package pack;

public class Claa {
	public void msg() {
		
		System.out.println("hello C");
	}

}
