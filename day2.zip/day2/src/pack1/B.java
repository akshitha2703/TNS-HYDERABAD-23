package pack1;
import day2.Userdefined;
import pack.*;
public class B {

	public static void main(String[] args) {
		Userdefined obj=new Userdefined();
		Claa obj1=new Claa();
		obj.msg();
		obj1.msg();
		

	}

}
