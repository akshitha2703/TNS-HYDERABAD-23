package com.example.service;









import java.util.List;

import com.example.entity.OrderDetailsEntity;

public interface OrderDetailsService {

	OrderDetailsEntity saveEntity(OrderDetailsEntity entity);

	List<OrderDetailsEntity> fetchOrderDetailsEntityList();

	OrderDetailsEntity fetchOrderDetailsEntityById(Long id);

	void deleteOrderDetailsEntityById(Long id);

	

	
	
	


}
