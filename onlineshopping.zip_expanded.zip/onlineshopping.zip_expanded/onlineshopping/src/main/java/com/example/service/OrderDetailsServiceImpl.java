package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.OrderDetailsEntity;
import com.example.repository.OrderDetailsRepository;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {
	@Autowired
	private OrderDetailsRepository repository;

	@Override
	public OrderDetailsEntity saveEntity(OrderDetailsEntity entity) {
		// TODO Auto-generated method stub
		return repository.save(entity);
	}

	@Override
	public List<OrderDetailsEntity> fetchOrderDetailsEntityList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public OrderDetailsEntity fetchOrderDetailsEntityById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public void deleteOrderDetailsEntityById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
		
	}
}
